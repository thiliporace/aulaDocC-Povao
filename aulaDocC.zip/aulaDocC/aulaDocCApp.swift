//
//  aulaDocCApp.swift
//  aulaDocC
//
//  Created by Thiago Liporace on 09/11/23.
//

import SwiftUI

@main
struct aulaDocCApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
